LightRays 2D by Andrii Sudyn

To create new LightRays 2D object in your scene, click on GameObject 
menu in Unity window, then go to Effects and then click LightRays2D.

That's it, now you have a quad with LightRays texture on it.
Now you can resize it, set the colors and adjust the sliders 
untill you achieve the desired effect.

There's also a version of this component which can be used with UI.
To add it to your Canvas object open GameObject menu, then go to
UI and click on LightRays2DCanvas.

My twitter: @ax23w4
Email: andrii.sudyn@gmail.com